﻿
namespace TCP_Chat
{
    partial class ChatClientForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.inputTextBox = new System.Windows.Forms.TextBox();
            this.displayTextBox = new System.Windows.Forms.TextBox();
            this.label_RecordID = new System.Windows.Forms.Label();
            this.textBox_RecordID = new System.Windows.Forms.TextBox();
            this.label_EmployeeID = new System.Windows.Forms.Label();
            this.textBox_EmployeeID = new System.Windows.Forms.TextBox();
            this.label_EntryTime = new System.Windows.Forms.Label();
            this.textBox_EntryTime = new System.Windows.Forms.TextBox();
            this.label_ExitTime = new System.Windows.Forms.Label();
            this.textBox_ExitTime = new System.Windows.Forms.TextBox();
            this.button_ReadDB = new System.Windows.Forms.Button();
            this.button_WriteDB_clockIn = new System.Windows.Forms.Button();
            this.button_WriteDB_clockOut = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // inputTextBox
            // 
            this.inputTextBox.Location = new System.Drawing.Point(12, 165);
            this.inputTextBox.Name = "inputTextBox";
            this.inputTextBox.Size = new System.Drawing.Size(412, 22);
            this.inputTextBox.TabIndex = 7;
            this.inputTextBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.inputTextBox_KeyDown);
            // 
            // displayTextBox
            // 
            this.displayTextBox.Location = new System.Drawing.Point(10, 193);
            this.displayTextBox.Multiline = true;
            this.displayTextBox.Name = "displayTextBox";
            this.displayTextBox.ReadOnly = true;
            this.displayTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.displayTextBox.Size = new System.Drawing.Size(414, 299);
            this.displayTextBox.TabIndex = 8;
            // 
            // label_RecordID
            // 
            this.label_RecordID.AutoSize = true;
            this.label_RecordID.Location = new System.Drawing.Point(64, 16);
            this.label_RecordID.Name = "label_RecordID";
            this.label_RecordID.Size = new System.Drawing.Size(67, 17);
            this.label_RecordID.TabIndex = 2;
            this.label_RecordID.Text = "RecordID";
            // 
            // textBox_RecordID
            // 
            this.textBox_RecordID.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.textBox_RecordID.Location = new System.Drawing.Point(137, 13);
            this.textBox_RecordID.Name = "textBox_RecordID";
            this.textBox_RecordID.ReadOnly = true;
            this.textBox_RecordID.Size = new System.Drawing.Size(232, 22);
            this.textBox_RecordID.TabIndex = 9;
            // 
            // label_EmployeeID
            // 
            this.label_EmployeeID.AutoSize = true;
            this.label_EmployeeID.Location = new System.Drawing.Point(44, 41);
            this.label_EmployeeID.Name = "label_EmployeeID";
            this.label_EmployeeID.Size = new System.Drawing.Size(87, 17);
            this.label_EmployeeID.TabIndex = 2;
            this.label_EmployeeID.Text = "Employee ID";
            // 
            // textBox_EmployeeID
            // 
            this.textBox_EmployeeID.Location = new System.Drawing.Point(138, 41);
            this.textBox_EmployeeID.Name = "textBox_EmployeeID";
            this.textBox_EmployeeID.Size = new System.Drawing.Size(229, 22);
            this.textBox_EmployeeID.TabIndex = 0;
            // 
            // label_EntryTime
            // 
            this.label_EntryTime.AutoSize = true;
            this.label_EntryTime.Location = new System.Drawing.Point(55, 69);
            this.label_EntryTime.Name = "label_EntryTime";
            this.label_EntryTime.Size = new System.Drawing.Size(76, 17);
            this.label_EntryTime.TabIndex = 2;
            this.label_EntryTime.Text = "Entry Time";
            // 
            // textBox_EntryTime
            // 
            this.textBox_EntryTime.Location = new System.Drawing.Point(137, 69);
            this.textBox_EntryTime.Name = "textBox_EntryTime";
            this.textBox_EntryTime.ReadOnly = true;
            this.textBox_EntryTime.Size = new System.Drawing.Size(229, 22);
            this.textBox_EntryTime.TabIndex = 2;
            // 
            // label_ExitTime
            // 
            this.label_ExitTime.AutoSize = true;
            this.label_ExitTime.Location = new System.Drawing.Point(66, 97);
            this.label_ExitTime.Name = "label_ExitTime";
            this.label_ExitTime.Size = new System.Drawing.Size(65, 17);
            this.label_ExitTime.TabIndex = 2;
            this.label_ExitTime.Text = "Exit Time";
            // 
            // textBox_ExitTime
            // 
            this.textBox_ExitTime.Location = new System.Drawing.Point(137, 97);
            this.textBox_ExitTime.Name = "textBox_ExitTime";
            this.textBox_ExitTime.ReadOnly = true;
            this.textBox_ExitTime.Size = new System.Drawing.Size(229, 22);
            this.textBox_ExitTime.TabIndex = 3;
            // 
            // button_ReadDB
            // 
            this.button_ReadDB.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_ReadDB.Location = new System.Drawing.Point(12, 125);
            this.button_ReadDB.Name = "button_ReadDB";
            this.button_ReadDB.Size = new System.Drawing.Size(84, 34);
            this.button_ReadDB.TabIndex = 5;
            this.button_ReadDB.Text = "Read DB";
            this.button_ReadDB.UseVisualStyleBackColor = true;
            this.button_ReadDB.Click += new System.EventHandler(this.button_ReadDB_Click);
            // 
            // button_WriteDB_clockIn
            // 
            this.button_WriteDB_clockIn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_WriteDB_clockIn.Location = new System.Drawing.Point(102, 125);
            this.button_WriteDB_clockIn.Name = "button_WriteDB_clockIn";
            this.button_WriteDB_clockIn.Size = new System.Drawing.Size(154, 34);
            this.button_WriteDB_clockIn.TabIndex = 6;
            this.button_WriteDB_clockIn.Text = "Write DB: clock-in";
            this.button_WriteDB_clockIn.UseVisualStyleBackColor = true;
            this.button_WriteDB_clockIn.Click += new System.EventHandler(this.button_WriteDB_clockIn_Click);
            // 
            // button_WriteDB_clockOut
            // 
            this.button_WriteDB_clockOut.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_WriteDB_clockOut.Location = new System.Drawing.Point(262, 125);
            this.button_WriteDB_clockOut.Name = "button_WriteDB_clockOut";
            this.button_WriteDB_clockOut.Size = new System.Drawing.Size(162, 34);
            this.button_WriteDB_clockOut.TabIndex = 6;
            this.button_WriteDB_clockOut.Text = "Write DB: clock-out";
            this.button_WriteDB_clockOut.UseVisualStyleBackColor = true;
            this.button_WriteDB_clockOut.Click += new System.EventHandler(this.button_WriteDB_clockOut_Click);
            // 
            // ChatClientForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(436, 498);
            this.Controls.Add(this.button_WriteDB_clockOut);
            this.Controls.Add(this.button_WriteDB_clockIn);
            this.Controls.Add(this.button_ReadDB);
            this.Controls.Add(this.textBox_ExitTime);
            this.Controls.Add(this.textBox_EntryTime);
            this.Controls.Add(this.label_ExitTime);
            this.Controls.Add(this.label_EntryTime);
            this.Controls.Add(this.textBox_EmployeeID);
            this.Controls.Add(this.label_EmployeeID);
            this.Controls.Add(this.textBox_RecordID);
            this.Controls.Add(this.label_RecordID);
            this.Controls.Add(this.displayTextBox);
            this.Controls.Add(this.inputTextBox);
            this.Name = "ChatClientForm";
            this.Text = "Client to read web database";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.ChatClientForm_FormClosing);
            this.Load += new System.EventHandler(this.ChatClientForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox inputTextBox;
        private System.Windows.Forms.TextBox displayTextBox;
        private System.Windows.Forms.Label label_RecordID;
        private System.Windows.Forms.TextBox textBox_RecordID;
        private System.Windows.Forms.Label label_EmployeeID;
        private System.Windows.Forms.TextBox textBox_EmployeeID;
        private System.Windows.Forms.Label label_EntryTime;
        private System.Windows.Forms.TextBox textBox_EntryTime;
        private System.Windows.Forms.Label label_ExitTime;
        private System.Windows.Forms.TextBox textBox_ExitTime;
        private System.Windows.Forms.Button button_ReadDB;
        private System.Windows.Forms.Button button_WriteDB_clockIn;
        private System.Windows.Forms.Button button_WriteDB_clockOut;
    }
}

