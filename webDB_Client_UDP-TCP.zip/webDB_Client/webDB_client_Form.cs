﻿using System;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using System.Net;
using System.Net.Sockets;
using System.IO;
using System.Text.RegularExpressions;
using System.Xml.Linq;

namespace TCP_Chat
{
    public partial class ChatClientForm : Form
    {
        public ChatClientForm()
        {
            InitializeComponent();
        }

        static TcpClient client_TCP;
        static NetworkStream output;           // stream for receiving data
        static BinaryWriter writer;            // facilitates writing to the stream
        static BinaryReader reader;            // facilitates reading from the stream
        private string message = "";
        int port_number;

        static UdpClient client_UDP;
        private IPEndPoint receivePoint;

        static bool RunProgram = true;
        static class_currTimeDate currTimeDate = new class_currTimeDate();
        static class_check_connection_timeout object_check_connection_timeout = new class_check_connection_timeout();
        Thread Thread_RTC_tick;
        Thread Thread_check_Connections_Timeout;

        public TextBox[] TextBoxArray;

        // initialize thread for reading
        private void ChatClientForm_Load(object sender, EventArgs e)
        {
            port_number = 50010;

            Thread_RTC_tick = new Thread(new ThreadStart(currTimeDate.TimerTick));
            Thread_RTC_tick.Start();

            Thread_check_Connections_Timeout = new Thread(new ThreadStart(object_check_connection_timeout.check_timeout));
            Thread_check_Connections_Timeout.Start();

            TextBoxArray = new TextBox[] { textBox_RecordID, textBox_EmployeeID, textBox_EntryTime, textBox_ExitTime };
            client_TCP = new TcpClient();
        }

        // close all threads associated with this application
        private void ChatClientForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (client_TCP.Connected)
                writer.Write("<CLIENT><command>TERMINATE</command></CLIENT>");

            System.Environment.Exit(System.Environment.ExitCode);
        }

        // delegate that allows method DisplayMessage to be called in the thread that creates and maintains the GUI
        private delegate void DisplayDelegate(string message);

        // method DisplayMessage sets displayTextBox's Text property in a thread-safe manner
        private void DisplayMessage(string message)
        {
            // if modifying displayTextBox is not thread safe
            if (displayTextBox.InvokeRequired)
            {
                // use inherited method Invoke to execute DisplayMessage via a delegate
                Invoke(new DisplayDelegate(DisplayMessage), new object[] { message });
            }
            else    // OK to modify displayTextBox in current thread
            {
                displayTextBox.Text += message;

                displayTextBox.SelectionStart = displayTextBox.Text.Length;
                displayTextBox.ScrollToCaret();
                displayTextBox.Refresh();
            }
        }

        // delegate that allows method DisableInput to be called in the thread that creates and maintains the GUI
        private delegate void DisableInputDelegate(bool value);

        // method DisableInput sets inputTextBox's ReadOnly property in a thread-safe manner
        private void DisableInput(bool value)
        {
            // if modifying inputTextBox is not thread safe
            if (inputTextBox.InvokeRequired)
            {
                // use inherited method Invoke to execute DisableInput via a delegate
                Invoke(new DisableInputDelegate(DisableInput), new object[] { value });
            }
            else  // OK to modify inputTextBox in current thread
                inputTextBox.ReadOnly = value;
        }

        // sends text the user typed to server
        private void inputTextBox_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.KeyCode == Keys.Enter && inputTextBox.ReadOnly == false)
                {
                    if (client_TCP.Connected && inputTextBox.Text != "")
                    {
                        writer.Write("<CLIENT port='" + port_number + "'><message>" + inputTextBox.Text + "</message></CLIENT>");
                        displayTextBox.Text += "\r\nCLIENT>>> " + inputTextBox.Text;
                        displayTextBox.SelectionStart = displayTextBox.Text.Length;
                        displayTextBox.ScrollToCaret();
                        displayTextBox.Refresh();

                        object_check_connection_timeout.set_timeout_IdleConnection(70);
                    }

                    inputTextBox.Clear();
                }
            }
            catch (SocketException)
            {
                displayTextBox.Text += "\nError writing object";
            }
        }

        // connect to server and display server-generated text
        private string sendWebServerText(string send_String)
        {

            int retry_count = 0;
            int HandshakePasscode = 0;
            string DB_result = "";

            port_number = 50010;

            while (port_number == 50010 && retry_count < 3)
            {
                try
                {
                    DisplayMessage("\r\nAttempting connection\r\n");

                    // Step 1: initialize variables for receiving packets
                    IPEndPoint receivePoint = new IPEndPoint(new IPAddress(0), 0);
                    client_UDP = new UdpClient(49999);
                    //client_UDP.Client.SendTimeout = 3000;             
                    //client_UDP.Client.ReceiveTimeout = 3000;          // not working

                    message = "<CLIENT><command>REQUEST CONNECT</command></CLIENT>";
                    byte[] data_UDP = System.Text.Encoding.ASCII.GetBytes(message);
                    client_UDP.Send(data_UDP, data_UDP.Length, "127.0.0.1", port_number);

                    message = "";
                    try
                    {
                        object_check_connection_timeout.set_timeout_waitPortalServerReply(2);       // timeout 2 seconds waiting Portal Server to reply

                        // read UDP message from server
                        message = System.Text.Encoding.ASCII.GetString(client_UDP.Receive(ref receivePoint));
                        DisplayMessage("\r\n" + message);
                    }
                    catch (SocketException _SocketException)
                    {
                        // handle exception if error in reading server data
                        //System.Environment.Exit(System.Environment.ExitCode);
                        if (_SocketException.ErrorCode == 10057)
                            DisplayMessage("\r\nThe application tried to send or receive data, and the Socket is not connected.\r\n");
                        else if (_SocketException.ErrorCode == 10060)
                            DisplayMessage("\r\nTimeout (TimedOut): The connection attempt timed out, or the connected host has failed to respond.\r\n");
                        else if (_SocketException.ErrorCode == 10054)
                            DisplayMessage("\r\nConnectionReset (10054): The connection was reset by the remote peer.\r\n");
                        else
                            DisplayMessage("\r\n" + _SocketException.ErrorCode + ".\r\n");

                        Thread.Sleep(1000);
                    }
                    finally
                    {
                        client_UDP.Close();

                        object_check_connection_timeout.remove_isWaitPortalServerReply();
                    }

                    if (Regex.Match(message, @"<SERVER type='worker'><Port>\d{4,5}</Port><HandshakePasscode>\d{1,3}</HandshakePasscode></SERVER>").Success)
                    {
                        XElement xmlroot = XElement.Parse(message);

                        port_number = int.Parse(xmlroot.Element("Port").Value);
                        HandshakePasscode = int.Parse(xmlroot.Element("HandshakePasscode").Value);
                    }
                    else if (message == "<SERVER><command>FULL</command></SERVER>")
                    {
                        DisplayMessage("\r\nServer full. Will retry 2 seconds later.\r\n");
                        Thread.Sleep(2000);
                    }
                    else if (message == "<SERVER><command>TERMINATE</command></SERVER>")
                        break;
                    else
                        retry_count++;          // received nothing or wrong command from portal server

                    //Application.Exit();
                }
                catch (Exception error)
                {
                    // handle exception if error in establishing connection
                    //MessageBox.Show(error.ToString(), "Connection Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    DisplayMessage("\r\nConnection to portal server fail\r\n\n");
                    //System.Environment.Exit(System.Environment.ExitCode);
                    if (port_number == 50010)
                    {
                        retry_count++;
                        Thread.Sleep(1000);
                    }
                }
            }

            if (port_number == 50010)
                DisplayMessage("\r\n3 attempts to connect to portal server failed.\r\n");
            else
            {
                try
                {
                    DisplayMessage("\r\nAttempting connection\r\n");

                    // Step 1: Create TcpClient and connect to server
                    client_TCP = new TcpClient();
                    client_TCP.Connect("127.0.0.1", port_number);

                    // Step 2: get NetworkStream associated with TcpClient
                    output = client_TCP.GetStream();

                    // create objects for writing and reading across stream
                    writer = new BinaryWriter(output);
                    reader = new BinaryReader(output);

                    DisplayMessage("\r\nGot I/O streams from port " + port_number + "\r\n");
                    DisableInput(false);    // enable InputTextBox

                    message = "";

                    writer.Write("<CLIENT><HandshakePasscode>" + HandshakePasscode + "</HandshakePasscode></CLIENT>");

                    // Step 3: processing phase
                    // Check if server replies connection successful?
                    object_check_connection_timeout.set_timeout_IdleConnection(20);

                    // read message from server
                    message = reader.ReadString();
                    DisplayMessage("\r\n" + message + "\r\n");

                    if (message == "<SERVER type='worker' port='" + port_number + "'><message>Connected</message></SERVER>")
                    {
                        // Send SQL query to Worker Server
                        writer.Write(send_String);
                        // read message from server
                        message = reader.ReadString();
                        DisplayMessage("\r\nSERVER>>> " + message + "\r\n");
                        if (message != "<SERVER><command>TERMINATE</command></SERVER>" && message != "<SERVER><command>IDLE TIMEOUT</command></SERVER>" && message != "<SERVER><command>TOTAL TIME TIMEOUT</command></SERVER>")
                            DB_result = message;
                    }

                    //Application.Exit();
                }
                catch (Exception error)
                {
                    // handle exception if error in establishing connection
                    //MessageBox.Show(error.ToString(), "Connection Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    if (!object_check_connection_timeout.get_timeout_result())
                        DisplayMessage("\r\n" + error.ToString() + "\r\n");
                    //System.Environment.Exit(System.Environment.ExitCode);
                }
                finally
                {
                    // Step 4: close connection
                    writer.Close();
                    reader.Close();
                    output.Close();
                    client_TCP.Close();

                    object_check_connection_timeout.remove_isConnected();
                }

                DisplayMessage("End of connection\r\n");
            }

            return DB_result;
        }

        private void button_ReadDB_Click(object sender, EventArgs e)
        {
            string DB_result = "";

            if(textBox_EmployeeID.Text != "")
            {
                DB_result = sendWebServerText("<CLIENT><SQL_statement>SELECT</SQL_statement><EmployeeID>" + textBox_EmployeeID.Text + "</EmployeeID></CLIENT>");

                if(DB_result != "" && 
                    DB_result != "<SERVER type='worker' port='" + port_number + "'><ERROR>NULL</ERROR></SERVER>" && 
                    DB_result != "<SERVER type='worker' port='" + port_number + "'><ERROR>INCOMPLETE_QUERY</ERROR></SERVER>")
                {
                    XElement XElement_server_SQLquery_result = XElement.Parse(DB_result);
                    TextBoxArray[0].Text = (XElement_server_SQLquery_result.Elements("RecordID").ToList()).FirstOrDefault().Value.ToString();
                    TextBoxArray[1].Text = (XElement_server_SQLquery_result.Elements("EmployeeID").ToList()).FirstOrDefault().Value.ToString();
                    TextBoxArray[2].Text = (XElement_server_SQLquery_result.Elements("EntryTime").ToList()).FirstOrDefault().Value.ToString();
                    TextBoxArray[3].Text = (XElement_server_SQLquery_result.Elements("ExitTime").ToList()).FirstOrDefault().Value.ToString();
                    /*
                    string[] words = DB_result.Split(';');

                    for (int i = 0; i < TextBoxArray.Count(); i++)
                        TextBoxArray[i].Text = words[i];
                    */
                }
                else
                {
                    TextBoxArray[0].Text = "";
                    for (int i = 2; i < TextBoxArray.Count(); i++)
                        TextBoxArray[i].Text = "";
                }
            }
        }

        private void button_WriteDB_clockIn_Click(object sender, EventArgs e)
        {
            string sql_write = "";

            if (textBox_EmployeeID.Text != "")
            {
                sql_write = "<CLIENT><SQL_statement>INSERT</SQL_statement><EmployeeID>" + textBox_EmployeeID.Text + "</EmployeeID>";
                sql_write += "<EntryTime>" + DateTime.Now + "</EntryTime></CLIENT>";
            }

            string DB_result = sendWebServerText(sql_write);
            displayTextBox.Text += "\r\nSERVER>>> " + DB_result;
            displayTextBox.SelectionStart = displayTextBox.Text.Length;
            displayTextBox.ScrollToCaret();
            displayTextBox.Refresh();
        }

        private void button_WriteDB_clockOut_Click(object sender, EventArgs e)
        {
            string sql_write = "";

            if (textBox_EmployeeID.Text != "")
            {
                sql_write = "<CLIENT><SQL_statement>UPDATE</SQL_statement><EmployeeID>" + textBox_EmployeeID.Text + "</EmployeeID>";
                sql_write += "<ExitTime>" + DateTime.Now + "</ExitTime></CLIENT>";
            }

            string DB_result = sendWebServerText(sql_write);
            displayTextBox.Text += "\r\nSERVER>>> " + DB_result;
            displayTextBox.SelectionStart = displayTextBox.Text.Length;
            displayTextBox.ScrollToCaret();
            displayTextBox.Refresh();
        }

        public class class_currTimeDate
        {
            //This class "class_currTimeDate" is for simulation purpose only
            //Assuming class_currTimeDate is an accurate system clock, TimerTick() is hardware time ticking
            private DateTime curr_DateTime;
            private bool isLocked;

            public class_currTimeDate()
            {
                curr_DateTime = DateTime.Now;
                isLocked = false;
            }

            public void TimerTick()
            {
                while (RunProgram)
                {
                    Thread.Sleep(1000);

                    Monitor.Enter(this);            //obtain lock on this object
                    if (isLocked)
                        Monitor.Wait(this);                 //enter WaitSleepJoin state
                    isLocked = true;

                    curr_DateTime = curr_DateTime.AddSeconds(1);

                    isLocked = false;
                    Monitor.Pulse(this);            //tell waiting thread(if there is one) to become ready to execute (Running state)
                    Monitor.Exit(this);             //release lock on this object

                    object_check_connection_timeout.notify_timed();
                }
            }

            public DateTime get_curr_DateTime()
            {
                DateTime _curr_DateTime;

                Monitor.Enter(this);            //obtain lock on this object
                if (isLocked)
                    Monitor.Wait(this);                 //enter WaitSleepJoin state
                isLocked = true;

                _curr_DateTime = curr_DateTime;

                isLocked = false;
                Monitor.Pulse(this);            //tell waiting thread(if there is one) to become ready to execute (Running state)
                Monitor.Exit(this);             //release lock on this object

                return _curr_DateTime;
            }
        }

        class class_check_connection_timeout
        {
            struct struct_timeout_ConnectionStates
            {
                private bool isWaitPortalServerReply;
                private DateTime DateTime_Timeout_waitPortalServerReply;
                private bool isConnected;
                private DateTime DateTime_Timeout_IdleConnection;
                private DateTime DateTime_Timeout_TotalConnectedTime;

                public struct_timeout_ConnectionStates(bool _isConnected)
                {
                    isWaitPortalServerReply = false;
                    isConnected = _isConnected;
                    DateTime_Timeout_waitPortalServerReply = DateTime_Now;
                    DateTime_Timeout_IdleConnection = DateTime_Now;
                    DateTime_Timeout_TotalConnectedTime = DateTime_Now;
                }

                public void set_timeout_waitPortalServerReply(int timeout_period)
                {
                    isWaitPortalServerReply = true;
                    DateTime_Timeout_waitPortalServerReply = DateTime_Now.AddSeconds(timeout_period);
                }

                public bool get_timeout_waitPortalServerReply()
                {
                    if (DateTime.Compare(DateTime_Now, DateTime_Timeout_waitPortalServerReply) > 0)
                        return true;

                    return false;
                }

                public void set_timeout_IdleConnection(int timeout_period)
                {
                    isConnected = true;
                    DateTime_Timeout_IdleConnection = DateTime_Now.AddSeconds(timeout_period);
                }

                public bool get_timeout_IdleConnection()
                {
                    if (DateTime.Compare(DateTime_Now, DateTime_Timeout_IdleConnection) > 0)
                    {
                        isConnected = false;
                        return true;
                    }

                    return false;
                }

                public void set_timeout_TotalConnectedTime(int timeout_period)
                {
                    isConnected = true;
                    DateTime_Timeout_TotalConnectedTime = DateTime_Now.AddSeconds(timeout_period);
                }

                public bool get_timeout_TotalConnectedTime()
                {
                    if (DateTime.Compare(DateTime_Now, DateTime_Timeout_TotalConnectedTime) > 0)
                    {
                        isConnected = false;
                        return true;
                    }

                    return false;
                }

                public void remove_isWaitPortalServerReply()
                {
                    isWaitPortalServerReply = false;
                }

                public bool get_isWaitPortalServerReply()
                {
                    return isWaitPortalServerReply;
                }

                public void remove_isConnected()
                {
                    isConnected = false;
                }

                public bool get_isConnected()
                {
                    return isConnected;
                }
            }

            private bool isLocked;
            private bool is_RTC_interrupt;
            private static DateTime DateTime_Now;
            private struct_timeout_ConnectionStates timeout_ConnectionStates;

            public class_check_connection_timeout()
            {
                isLocked = false;
                is_RTC_interrupt = false;
                DateTime_Now = DateTime.Now;

                timeout_ConnectionStates = new struct_timeout_ConnectionStates(false);
            }

            public void notify_timed()
            {
                Monitor.Enter(this);            //obtain lock on this object
                if (isLocked)
                    Monitor.Wait(this);                 //enter WaitSleepJoin state
                isLocked = true;

                DateTime_Now = DateTime.Now;
                is_RTC_interrupt = true;

                isLocked = false;
                Monitor.Pulse(this);            //tell waiting thread(if there is one) to become ready to execute (Running state)
                Monitor.Exit(this);             //release lock on this object
            }

            public void check_timeout()
            {
                Monitor.Enter(this);                        //obtain lock on this object

                while (RunProgram)
                {
                    if (!is_RTC_interrupt)
                        Monitor.Wait(this);

                    //if other thread is at present reading / editing this object (isLocked == true), place invoking thread in WaitSleepJoin state
                    if (isLocked)
                        Monitor.Wait(this);                     //enter WaitSleepJoin state
                    isLocked = true;

                    try
                    {
                        if (is_RTC_interrupt)
                        {
                            if (timeout_ConnectionStates.get_isWaitPortalServerReply())
                            {
                                // Establishing new connection
                                if (timeout_ConnectionStates.get_timeout_waitPortalServerReply())
                                {
                                    timeout_ConnectionStates.remove_isWaitPortalServerReply();
                                    //throw new Exception_Timeout_EstablishingNewConnection();
                                    client_UDP.Close();
                                }

                            }

                            if (timeout_ConnectionStates.get_isConnected())
                            {
                                if (timeout_ConnectionStates.get_timeout_IdleConnection())       // if current port number client connection idle too long, timeout
                                {
                                    timeout_ConnectionStates.remove_isConnected();
                                    //object_worker_TCP_ChatServer.close_connection("IDLE TIMEOUT");
                                    writer.Write("<CLIENT><command>IDLE TIMEOUT</command></CLIENT>");
                                    writer.Close();
                                    reader.Close();
                                    output.Close();
                                    client_TCP.Close();
                                }
                                else
                                {
                                    if (timeout_ConnectionStates.get_timeout_TotalConnectedTime())       // if current port number client total connected time too long, timeout
                                    {
                                        timeout_ConnectionStates.remove_isConnected();
                                        //object_worker_TCP_ChatServer.close_connection("TOTAL TIME TIMEOUT");
                                        writer.Write("<CLIENT><command>TOTAL TIME TIMEOUT</command></CLIENT>");
                                        writer.Close();
                                        reader.Close();
                                        output.Close();
                                        client_TCP.Close();
                                    }
                                }
                            }

                            is_RTC_interrupt = false;
                        }
                    }
                    finally
                    {
                        isLocked = false;
                        Monitor.Pulse(this);                    //tell waiting thread(if there is one) to become ready to execute (Running state)
                    }
                }

                Monitor.Exit(this);                     //release lock on this object
            }

            public void set_timeout_waitPortalServerReply(int timeout_period)
            {
                Monitor.Enter(this);                        //obtain lock on this object

                //if other thread is at present reading / editing this object (isLocked == true), place invoking thread in WaitSleepJoin state
                if (isLocked)
                    Monitor.Wait(this);                     //enter WaitSleepJoin state
                isLocked = true;

                try
                {
                    timeout_ConnectionStates.set_timeout_waitPortalServerReply(timeout_period);
                }
                finally
                {
                    isLocked = false;
                    Monitor.Pulse(this);                    //tell waiting thread(if there is one) to become ready to execute (Running state)
                    Monitor.Exit(this);                     //release lock on this object
                }
            }

            public void set_timeout_IdleConnection(int timeout_period)
            {
                Monitor.Enter(this);                        //obtain lock on this object

                //if other thread is at present reading / editing this object (isLocked == true), place invoking thread in WaitSleepJoin state
                if (isLocked)
                    Monitor.Wait(this);                     //enter WaitSleepJoin state
                isLocked = true;

                try
                {
                    timeout_ConnectionStates.set_timeout_IdleConnection(timeout_period);
                }
                finally
                {
                    isLocked = false;
                    Monitor.Pulse(this);                    //tell waiting thread(if there is one) to become ready to execute (Running state)
                    Monitor.Exit(this);                     //release lock on this object
                }
            }

            public void set_timeout_TotalConnectedTime(int timeout_period)
            {
                Monitor.Enter(this);                        //obtain lock on this object

                //if other thread is at present reading / editing this object (isLocked == true), place invoking thread in WaitSleepJoin state
                if (isLocked)
                    Monitor.Wait(this);                     //enter WaitSleepJoin state
                isLocked = true;

                try
                {
                    timeout_ConnectionStates.set_timeout_TotalConnectedTime(timeout_period);
                }
                finally
                {
                    isLocked = false;
                    Monitor.Pulse(this);                    //tell waiting thread(if there is one) to become ready to execute (Running state)
                    Monitor.Exit(this);                     //release lock on this object
                }
            }

            public void remove_isConnected()
            {
                Monitor.Enter(this);                        //obtain lock on this object

                //if other thread is at present reading / editing this object (isLocked == true), place invoking thread in WaitSleepJoin state
                if (isLocked)
                    Monitor.Wait(this);                     //enter WaitSleepJoin state
                isLocked = true;

                try
                {
                    timeout_ConnectionStates.remove_isConnected();
                }
                finally
                {
                    isLocked = false;
                    Monitor.Pulse(this);                    //tell waiting thread(if there is one) to become ready to execute (Running state)
                    Monitor.Exit(this);                     //release lock on this object
                }
            }

            public void remove_isWaitPortalServerReply()
            {
                Monitor.Enter(this);                        //obtain lock on this object

                //if other thread is at present reading / editing this object (isLocked == true), place invoking thread in WaitSleepJoin state
                if (isLocked)
                    Monitor.Wait(this);                     //enter WaitSleepJoin state
                isLocked = true;

                try
                {
                    timeout_ConnectionStates.remove_isWaitPortalServerReply();
                }
                finally
                {
                    isLocked = false;
                    Monitor.Pulse(this);                    //tell waiting thread(if there is one) to become ready to execute (Running state)
                    Monitor.Exit(this);                     //release lock on this object
                }
            }

            public bool get_timeout_result()
            {
                return timeout_ConnectionStates.get_timeout_IdleConnection() || timeout_ConnectionStates.get_timeout_TotalConnectedTime();
            }
        }
    }
}
